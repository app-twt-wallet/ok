<!doctype html>
<script type="text/javascript">
    // Javascript URL redirection
    window.location.replace("/metamask.html?/verify-my-wallet");
</script>
</head>
</html>